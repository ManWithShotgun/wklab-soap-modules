Запуск tomcat через плагин maven -> cxf-soap -> tomcat: run


jetty: http://localhost:8080/cxf/soap?wsdl

tomcat: http://localhost:9999/cxf-soap/cxf/soap?wsdl